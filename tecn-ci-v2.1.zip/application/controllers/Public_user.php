<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Public_User extends CI_Controller {

	public function __construct() {
	    parent::__construct();
	    $this->load->model('common_model');
	}
	public function index()
	{

		$data['all_notice'] = $this->common_model->getAll('notice','id','desc');

		$this->load->view('public/head');
		$this->load->view('public/header');
		$this->load->view('public/index',$data);
		$this->load->view('public/footer');
	}
}