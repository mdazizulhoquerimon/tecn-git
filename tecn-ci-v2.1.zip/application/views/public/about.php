<?php 
include('head.php');
include('header.php');
?>
<div class="about-area">
	<div class="section-top-banner">
		<!-- <img src="images/campus-img.jpg" alt="TECN"> -->
		<div class="container">
			<div class="section-top-banner-links">
				<h1>About TECN</h1>
				<nav aria-label="breadcrumb">
				  <ol class="breadcrumb">
				    <li class="breadcrumb-item"><a href="#">Home</a></li>
				    <li class="breadcrumb-item"><a href="#">Library</a></li>
				    <li class="breadcrumb-item active" aria-current="page">About TECN</li>
				  </ol>
				</nav>
			</div>
		</div>
	</div>

	<div class="about-area-body">
		<div class="container">
			<div class="about-area-body-title">
				<h2>Overview of TECN</h2>
			</div>
			<div class="about-area-body-title">
				<p>
					The Textile Engineering College, Begumgonj, Noakhali (TCEN) (Bengali: টেক্সটাইল ইঞ্জিনিয়ারিং কলেজ, বেগমগঞ্জ, নোয়াখালী) is a textile engineering educational institute in Noakhali, Chittagong, Bangladesh. 
					<br><br>
					It is affiliated with Bangladesh University of Textiles (BUTEX). 
					<br><br>
					It is one of the six textile engineering colleges which are directly controlled by Ministry of Textiles & Jute, Bangladesh.

				</p>
				<p>
					The Textile Engineering College, Begumgonj, Noakhali (TCEN) (Bengali: টেক্সটাইল ইঞ্জিনিয়ারিং কলেজ, বেগমগঞ্জ, নোয়াখালী) is a textile engineering educational institute in Noakhali, Chittagong, Bangladesh. 
					<br><br>
					It is affiliated with Bangladesh University of Textiles (BUTEX). 
					<br><br>
					It is one of the six textile engineering colleges which are directly controlled by Ministry of Textiles & Jute, Bangladesh.

				</p>
				<p>
					The Textile Engineering College, Begumgonj, Noakhali (TCEN) (Bengali: টেক্সটাইল ইঞ্জিনিয়ারিং কলেজ, বেগমগঞ্জ, নোয়াখালী) is a textile engineering educational institute in Noakhali, Chittagong, Bangladesh. 
					<br><br>
					It is affiliated with Bangladesh University of Textiles (BUTEX). 
					<br><br>
					It is one of the six textile engineering colleges which are directly controlled by Ministry of Textiles & Jute, Bangladesh.

				</p>
			</div>
		</div>
	</div>
</div>
<?php
include('footer.php');
?>