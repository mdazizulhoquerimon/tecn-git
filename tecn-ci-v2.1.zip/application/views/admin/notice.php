<div class="page-wrapper">
    <div class="content container-fluid">
        <div class="row">
            <!-- <div class="col-xs-12">
                <h4 class="page-title">Notice</h4>
            </div> -->
            <?php if($success == 1){?>
            <script>
            	alert("Notice Successfully Inserted.");
            </script>
        	<?php }?>
        	
            <div class="card-box">
            	<div class="notice-form">
	                <h2 class="text-center">Notice</h2>
	                <br>
					<?php echo validation_errors(); ?>

					<?php echo form_open_multipart('admin/insert_notice','class="form-horizontal"'); ?>

					     <div class="form-group">
	                        <label class="control-label col-lg-2">Title</label>
	                        <div class="col-md-10">
	                            <input type="text" name="title" class="form-control" placeholder="Notice Title">
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="control-label col-lg-2">Description</label>
	                        <div class="col-lg-10">
	                            <textarea name="description" rows="5" cols="5" class="form-control" placeholder="Notice description here"></textarea>
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="control-label col-lg-2">Notice Image</label>
	                        <div class="col-lg-10">
	                            <input name="notice-image" class="form-control" type="file">
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="control-label col-lg-2">Date</label>
	                        <div class="col-md-10">
	                            <input type="text" name="notice-date" class="form-control" value="<?php echo date('Y-m-d H:i:s');?>">
	                        </div>
	                    </div>

	                    <div class="text-center">
	                    	<button type="submit" class="btn btn-primary">Submit</button>
	                    </div>

					</form>

	                <!-- <form class="form-horizontal" method="post" action="#">
	                    <div class="form-group">
	                        <label class="control-label col-lg-2">Title</label>
	                        <div class="col-md-10">
	                            <input type="text" class="form-control" placeholder="Notice Title">
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="control-label col-lg-2">Description</label>
	                        <div class="col-lg-10">
	                            <textarea rows="5" cols="5" class="form-control" placeholder="Notice description here"></textarea>
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="control-label col-lg-2">Notice Image</label>
	                        <div class="col-lg-10">
	                            <input class="form-control" type="file">
	                        </div>
	                    </div>
	                    <div class="form-group">
	                        <label class="control-label col-lg-2">Date</label>
	                        <div class="col-md-10">
	                            <input type="text" class="form-control" name="notice-date" value="<?php echo date('Y-m-d H:i:s');?>">
	                        </div>
	                    </div>
	                    <div class="text-center">
	                    	<button type="submit" class="btn btn-primary">Submit</button>
	                    </div>
	                </form> -->
            	</div>
            	<br><br><br>
            	<div class="all-notice">
		            <div class="content container-fluid">
		                <div class="row">
		                    <div class="col-xs-12">
		                        <h4 class="page-title">All Notices</h4>
		                    </div>
		                </div>
		                <div class="row">
		                    <div class="col-lg-12">
		                        <div class="card-box">
		                            <div class="card-block">
		                                <h6 class="card-title text-bold">Default Datatable</h6>
		                                <p class="content-group">
		                                    This is the most basic example of the datatables with zero configuration. Use the <code>.datatable</code> class to initialize datatables.
		                                </p>
		                                <table class="display datatable table table-stripped">
		                                    <thead>
		                                        <tr>
		                                            <th>Name</th>
		                                            <th>Position</th>
		                                            <th>Office</th>
		                                            <th>Age</th>
		                                            <th>Start date</th>
		                                            <th>Salary</th>
		                                        </tr>
		                                    </thead>
		                                    <tbody>
		                                        
		                                        <tr>
		                                            <td>Olivia Liang</td>
		                                            <td>Support Engineer</td>
		                                            <td>Singapore</td>
		                                            <td>64</td>
		                                            <td>2011/02/03</td>
		                                            <td>$234,500</td>
		                                        </tr>
		                                        <tr>
		                                            <td>Bruno Nash</td>
		                                            <td>Software Engineer</td>
		                                            <td>London</td>
		                                            <td>38</td>
		                                            <td>2011/05/03</td>
		                                            <td>$163,500</td>
		                                        </tr>
		                                        <tr>
		                                            <td>Sakura Yamamoto</td>
		                                            <td>Support Engineer</td>
		                                            <td>Tokyo</td>
		                                            <td>37</td>
		                                            <td>2009/08/19</td>
		                                            <td>$139,575</td>
		                                        </tr>
		                                        <tr>
		                                            <td>Thor Walton</td>
		                                            <td>Developer</td>
		                                            <td>New York</td>
		                                            <td>61</td>
		                                            <td>2013/08/11</td>
		                                            <td>$98,540</td>
		                                        </tr>
		                                        <tr>
		                                            <td>Finn Camacho</td>
		                                            <td>Support Engineer</td>
		                                            <td>San Francisco</td>
		                                            <td>47</td>
		                                            <td>2009/07/07</td>
		                                            <td>$87,500</td>
		                                        </tr>
		                                        <tr>
		                                            <td>Serge Baldwin</td>
		                                            <td>Data Coordinator</td>
		                                            <td>Singapore</td>
		                                            <td>64</td>
		                                            <td>2012/04/09</td>
		                                            <td>$138,575</td>
		                                        </tr>
		                                        <tr>
		                                            <td>Donna Snider</td>
		                                            <td>Customer Support</td>
		                                            <td>New York</td>
		                                            <td>27</td>
		                                            <td>2011/01/25</td>
		                                            <td>$112,000</td>
		                                        </tr>
		                                    </tbody>
		                                </table>
		                            </div>
		                        </div>
		                    </div>
		                </div>
		            </div>
            	</div>
            </div>

        </div>
    </div>
</div>