<?php
class Admin_Model extends CI_Model {

    public function __construct()
    {
        $this->load->database();
    }
	public function insert_notice()
	{
	    $this->load->helper('url');

	    //$slug = url_title($this->input->post('title'), 'dash', TRUE);

	    $data = array(
	        'title' => $this->input->post('title'),
	        //'slug' => $slug,
	        'description' => $this->input->post('description'),
	        'date' => date('Y-m-d',strtotime($this->input->post('notice-date'))),
	        'date_time' => $this->input->post('notice-date')
	    );

	    return $this->db->insert('notice', $data);
	}
}
?>