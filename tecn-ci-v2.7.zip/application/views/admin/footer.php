    </div>
    <div class="sidebar-overlay" data-reff=""></div>
    <script type="text/javascript" src="<?php echo base_url();?>assets-admin/js/jquery-3.2.1.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets-admin/js/bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets-admin/js/jquery.slimscroll.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets-admin/js/jquery.dataTables.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets-admin/js/dataTables.bootstrap.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets-admin/js/jquery-ui.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets-admin/js/select2.min.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets-admin/js/app.js"></script>
    <script type="text/javascript" src="<?php echo base_url();?>assets-admin/js/custom_admin.js"></script>
</body>

</html>