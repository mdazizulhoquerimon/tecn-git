"# tecn" 
