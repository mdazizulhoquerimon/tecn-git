<?php include ('header.php'); ?>
        <div class="page-wrapper">
            <div class="content container-fluid">
                <div class="row">
                    <div class="col-xs-12">
                        <h4 class="page-title">Blank Page</h4>
                    </div>
                </div>
            </div>
        </div>
<?php include ('footer.php'); ?>