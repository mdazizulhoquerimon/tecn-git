<?php include('head.php');?>
<div class="coming-soon d-flex align-content-center justified-content-center">
	<div class="coming-soon-in">
		<div class="notice">
			<h4>নোটিশ বোর্ড</h4>
			<div class="notice-body">
				<a href="http://localhost/tecn/doc/Citizens-Charter-2019.pdf" title="Citizens Charter" target="_blank">১। সেবা প্রদানের প্রতিশ্রুতি ( Citizen's Charter)</a>
				<br>
				<a href="http://localhost/tecn/doc/Citizens-Charter-2019.pdf" title="Citizens Charter" target="_blank">২। বার্ষিক কর্ম সম্পাদন</a>
			</div>
		</div>
		<div class="coming-logo">
			<img src="images/logo-white.png" alt="Textile Engineering College, Noakhali">
		</div>
		<div class="divider">
			<img src="images/divider.png" alt="">
		</div>
		<div class="clg-title">
				টেক্সটাইল ইঞ্জিনিয়ারিং কলেজ, নোয়াখালি 
		</div>

		<div class="divider">
			<img src="images/divider.png" alt="">
		</div>
		<div class="coming-soon-text">
			<h1>
				Stay Tuned
			</h1>
			<h5>
				We are coming soon!!
			</h5>
		</div>

	</div>
</div>
<?php include('footer.php');?>